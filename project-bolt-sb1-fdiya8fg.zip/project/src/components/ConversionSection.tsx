import React, { useState } from 'react';
import { LucideIcon, Share2 } from 'lucide-react';

interface ConversionSectionProps {
  icon: LucideIcon;
  title: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  output: string;
  iconColor: string;
  outputLabel: string;
}

export default function ConversionSection({
  icon: Icon,
  title,
  value,
  onChange,
  placeholder,
  output,
  iconColor,
  outputLabel,
}: ConversionSectionProps) {
  const [showCopied, setShowCopied] = useState(false);

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(output);
      setShowCopied(true);
      setTimeout(() => setShowCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center gap-2 mb-4">
        <Icon className={iconColor} />
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full h-32 p-3 border rounded-md mb-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      />
      {output && (
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium">{outputLabel}:</h3>
            <div className="relative">
              <button
                onClick={handleShare}
                className="inline-flex items-center gap-2 px-3 py-1 text-sm rounded-md bg-gray-100 hover:bg-gray-200 transition-colors"
              >
                <Share2 size={16} />
                Share
              </button>
              {showCopied && (
                <div className="absolute right-0 -top-8 bg-black text-white text-xs px-2 py-1 rounded">
                  Copied!
                </div>
              )}
            </div>
          </div>
          <div className="bg-gray-100 p-3 rounded-md break-all">
            {output}
          </div>
        </div>
      )}
    </div>
  );
}