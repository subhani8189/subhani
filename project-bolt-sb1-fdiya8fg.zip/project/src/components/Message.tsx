import React from 'react';
import { Share2 } from 'lucide-react';
import { formatTimestamp } from '../utils/dateFormat';

interface MessageProps {
  text: string;
  binary: string;
  type: 'sent' | 'received';
  timestamp: string;
  onShare?: () => void;
}

export default function Message({ text, binary, type, timestamp, onShare }: MessageProps) {
  const isReceived = type === 'received';
  
  return (
    <div className={`flex ${isReceived ? 'justify-start' : 'justify-end'} mb-4`}>
      <div className={`max-w-[80%] rounded-lg p-3 relative group ${
        isReceived ? 'bg-white' : 'bg-[#d9fdd3]'
      }`}>
        <p className="break-words mb-2">{text}</p>
        <p className="text-sm text-gray-600 font-mono break-all mb-2">{binary}</p>
        <div className="flex items-center justify-between mt-1">
          <span className="text-xs text-gray-500">
            {formatTimestamp(timestamp)}
          </span>
          {onShare && (
            <button
              onClick={onShare}
              className="opacity-0 group-hover:opacity-100 transition-opacity ml-2 p-1 hover:bg-gray-100 rounded"
              title="Share message"
            >
              <Share2 size={14} className="text-gray-500" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}