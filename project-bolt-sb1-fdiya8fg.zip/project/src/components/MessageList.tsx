import React from 'react';
import Message from './Message';
import { MessageData } from '../types/message';

interface MessageListProps {
  messages: MessageData[];
  onShare: (text: string) => void;
}

export default function MessageList({ messages, onShare }: MessageListProps) {
  return (
    <div className="flex flex-col space-y-4 pb-20">
      {messages.map((msg) => (
        <Message
          key={msg.id}
          text={msg.text}
          binary={msg.binary}
          type={msg.binary ? 'sent' : 'received'}
          timestamp={msg.timestamp}
          onShare={() => onShare(msg.text)}
        />
      ))}
    </div>
  );
}