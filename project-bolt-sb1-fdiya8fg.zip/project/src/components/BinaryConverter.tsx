import React, { useCallback } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { encryptToBinary } from '../utils/binaryConverter';
import { createMessage } from '../utils/messageUtils';
import ChatLayout from './ChatLayout';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import { MessageData } from '../types/message';

export default function BinaryConverter() {
  const [messages, setMessages] = useLocalStorage<MessageData[]>('binaryConverter.messages', []);
  const [currentInput, setCurrentInput] = useLocalStorage('binaryConverter.currentInput', '');

  const handleInputChange = useCallback((text: string) => {
    setCurrentInput(text);
  }, [setCurrentInput]);

  const handleSendMessage = useCallback(() => {
    if (currentInput.trim()) {
      const binary = encryptToBinary(currentInput);
      // Create a message with both original text and binary
      const newMessage = createMessage(currentInput, binary);
      setMessages(prev => [...prev, newMessage]);
      setCurrentInput('');
    }
  }, [currentInput, setMessages, setCurrentInput]);

  const handleShare = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  return (
    <ChatLayout>
      <MessageList messages={messages} onShare={handleShare} />
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#efeae2]">
        <MessageInput
          value={currentInput}
          onChange={handleInputChange}
          onSend={handleSendMessage}
          placeholder="Type a message to convert to binary..."
        />
      </div>
    </ChatLayout>
  );
}