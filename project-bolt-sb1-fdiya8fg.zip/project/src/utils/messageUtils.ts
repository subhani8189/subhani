import { MessageData } from '../types/message';

export function createMessage(text: string, binary: string): MessageData {
  return {
    id: crypto.randomUUID(),
    text,
    binary,
    timestamp: new Date().toISOString()
  };
}