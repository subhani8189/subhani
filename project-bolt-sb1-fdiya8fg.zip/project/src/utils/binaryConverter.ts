export const encryptToBinary = (text: string): string => {
  if (!text) return '';
  return text
    .split('')
    .map(char => char.charCodeAt(0).toString(2).padStart(8, '0'))
    .join(' ');
};

export const decryptFromBinary = (binary: string): string => {
  if (!binary) return '';
  try {
    return binary
      .split(' ')
      .map(bin => String.fromCharCode(parseInt(bin, 2)))
      .join('');
  } catch (error) {
    return 'Invalid binary format';
  }
};