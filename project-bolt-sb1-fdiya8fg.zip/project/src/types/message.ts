export interface MessageData {
  id: string;
  text: string;
  binary: string;
  timestamp: string;
}